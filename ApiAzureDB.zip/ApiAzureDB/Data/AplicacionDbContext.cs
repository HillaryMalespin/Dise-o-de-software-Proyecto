using Microsoft.EntityFrameworkCore;
//using ApiAzureDB.Modelo;

namespace ApiAzureDB.Data
{
    public class AplicacionDbContext : DbContext
    {
        public AplicacionDbContext(DbContextOptions<AplicacionDbContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<CarpetaTematica> CarpetasTematicas { get; set; }
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Documento> Documentos { get; set; }
        public DbSet<DocumentoCarpeta> DocumentoCarpetas { get; set; }
        public DbSet<DocumentoCategoria> DocumentoCategorias { get; set; }
        public DbSet<Noticia> Noticias { get; set; }
        public DbSet<Notificacion> Notificaciones { get; set; }
        public DbSet<LogAuditoria> LogsAuditoria { get; set; }
        public DbSet<DocumentoDescargado> DocumentosDescargados { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Relaciones muchos a muchos (sin clase intermedia con ID)
            modelBuilder.Entity<DocumentoCarpeta>()
                .HasKey(dc => new { dc.DocumentoID, dc.CarpetaID });

            modelBuilder.Entity<DocumentoCategoria>()
                .HasKey(dc => new { dc.DocumentoID, dc.CategoriaID });
        }
    }
}
